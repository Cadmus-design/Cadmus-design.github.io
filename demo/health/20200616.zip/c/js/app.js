$(function () {
   $(".header").load("c/js/header.html");

});